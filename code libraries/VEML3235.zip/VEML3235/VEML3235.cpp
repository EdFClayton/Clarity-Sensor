/*!
 *  @file VEML3235.cpp
 *
 * 	I2C Driver for the VEML3235 I2C Lux sensor
 *
 * 	This is an adaptation of the library for the Adafruit VEML7700 breakout:
 * 	http://www.adafruit.com/
 *	
 *	Author: E Clayton 19/11/2023 University of Auckland
 *
 *     v0.1 - Draft release
 */

#include "VEML3235.h"

/*!
 *    @brief  Instantiates a new VEML3235 class
 */
VEML3235::VEML3235() {}
//  _sensorID = sensorID;
//}

/*!
 *    @brief  Sets up the hardware for talking to the VEML3235
 *    @param  theWire An optional pointer to an I2C interface
 *    @return True if initialization was successful, otherwise false.
 */
bool VEML3235::begin(TwoWire *theWire) {
  i2c_dev = new Adafruit_I2CDevice(VEML3235_I2CADDR_DEFAULT, theWire);

  if (!i2c_dev->begin()) {
    return false;
  }

  ALS_Config =
      new Adafruit_I2CRegister(i2c_dev, VEML3235_ALS_CONFIG, 2, LSBFIRST);
  ALS_Data = new Adafruit_I2CRegister(i2c_dev, VEML3235_ALS_DATA, 2, LSBFIRST);
  White_Data =
      new Adafruit_I2CRegister(i2c_dev, VEML3235_WHITE_DATA, 2, LSBFIRST);

  ALS_Shutdown =
      new Adafruit_I2CRegisterBits(ALS_Config, 1, 15); // SD0 (# bits, bit_shift)
  Power_Save = 
	  new Adafruit_I2CRegisterBits(ALS_Config, 1, 0); // SD
  ALS_Integration_Time = new Adafruit_I2CRegisterBits(ALS_Config, 3, 4);
  ALS_Gain = new Adafruit_I2CRegisterBits(ALS_Config, 2, 11);

  enable(false);
  setGain(VEML3235_GAIN_4);
  setIntegrationTime(VEML3235_IT_800MS);
  enable(true);

  lastRead = millis();

  return true;
}

/*!
 *    @brief Read the calibrated lux value. See app note lux table on page 5
 *    @param method Lux comptation method to use. One of
 *    @returns Floating point Lux data
 */
float VEML3235::readLux(luxMethod method) {
  bool wait = true;
  switch (method) {
  case VEML_LUX_NORMAL_NOWAIT:
    wait = false;
    VEML3235_FALLTHROUGH
  case VEML_LUX_NORMAL:
    return computeLux(readALS(wait));
  case VEML_LUX_CORRECTED_NOWAIT:
    wait = false;
    VEML3235_FALLTHROUGH
  case VEML_LUX_CORRECTED:
    return computeLux(readALS(wait), true);
  case VEML_LUX_AUTO:
    return autoLux();
  default:
    return -1;
  }
}

/*!
 *    @brief Read the raw ALS data
 *    @param wait If false (default), read out measurement with no delay. If
 * true, wait as need based on integration time before reading out measurement
 * results.
 *    @returns 16-bit data value from the ALS register
 */
uint16_t VEML3235::readALS(bool wait) {
  if (wait)
    readWait();
  lastRead = millis();
  return ALS_Data->read();
}

/*!
 *    @brief Read the raw white light data
 *    @param wait If false (default), read out measurement with no delay. If
 * true, wait as need based on integration time before reading out measurement
 * results.
 *    @returns 16-bit data value from the WHITE register
 */
uint16_t VEML3235::readWhite(bool wait) {
  if (wait)
    readWait();
  lastRead = millis();
  return White_Data->read();
}

/*!
 *    @brief Enable or disable the sensor
 *    @param enable The flag to enable/disable
 */
void VEML3235::enable(bool enable) {
  ALS_Shutdown->write(!enable);
  Power_Save->write(!enable);
  // From app note:
  //   '''
  //   When activating the sensor, set bit 15 of the command register
  //   to “0” with a wait time of 4 ms before the first measurement
  //   is needed, allowing for the correct start of the signal
  //   processor and oscillator.
  //   '''
  if (enable)
    delay(8); // doubling 4ms spec to be sure
	ALS_SD = false;
	PowerSave = false;
}

void VEML3235::turnOn(bool turnOn) {
	if (!turnOn)
		ALS_SD = true;
		PowerSave = true;
}

/*!
 *    @brief Set ALS integration time
 *    @param it Can be VEML3235_IT_100MS, VEML3235_IT_200MS, VEML3235_IT_400MS,
 *    VEML3235_IT_800MS, VEML3235_IT_50MS
 *    @param wait Waits to ensure old integration time cycle has completed. This
 * is a blocking delay. If disabled by passing false, user code must insure a
 * new reading is not done before old integration cycle completes.
 */
void VEML3235::setIntegrationTime(uint8_t it, bool wait) {
  // save current integration time
  int flushDelay = wait ? getIntegrationTimeValue() : 0;
  // set new integration time
  ALS_Integration_Time->write(it);
  // pause old integration time to insure sensor cycle has completed
  delay(flushDelay);
  // reset counter
  lastRead = millis();
}

/*!
 *    @brief Get ALS integration time setting
 *    @returns IT index, can be VEML3235_IT_100MS, VEML3235_IT_200MS,
 * VEML3235_IT_400MS, VEML3235_IT_800MS, VEML3235_IT_50MS
 */
uint8_t VEML3235::getIntegrationTime(void) {
  return ALS_Integration_Time->read();
}

/*!
 *    @brief Get ALS integration time value
 *    @returns ALS integration time in milliseconds
 */
int VEML3235::getIntegrationTimeValue(void) {
  switch (getIntegrationTime()) {
  case VEML3235_IT_50MS:
    return 50;
  case VEML3235_IT_100MS:
    return 100;
  case VEML3235_IT_200MS:
    return 200;
  case VEML3235_IT_400MS:
    return 400;
  case VEML3235_IT_800MS:
    return 800;
  default:
    return -1;
  }
}

/*!
 *    @brief Set ALS gain
 *    @param gain Can be VEML3235_GAIN_1, VEML3235_GAIN_2, VEML3235_GAIN_4
 */
void VEML3235::setGain(uint8_t gain) {
  ALS_Gain->write(gain);
  lastRead = millis(); // reset
}

/*!
 *    @brief Get ALS gain setting
 *    @returns Gain index, can be VEML3235_GAIN_1, VEML3235_GAIN_2,
 * VEML3235_GAIN_4
 */
uint8_t VEML3235::getGain(void) { return ALS_Gain->read(); }

/*!
 *    @brief Get ALS gain value
 *    @returns Actual gain value as float
 */
float VEML3235::getGainValue(void) {
  switch (getGain()) {
  case VEML3235_GAIN_1:
    return 1;
  case VEML3235_GAIN_2:
    return 2;
  case VEML3235_GAIN_4:
    return 4;
  default:
    return -1;
  }
}

/*!
 *    @brief Determines resolution for current gain and integration time
 * settings.
 */
float VEML3235::getResolution(void) {
  return MAX_RES * (IT_MAX / getIntegrationTimeValue()) *
         (GAIN_MAX / getGainValue());
}

/*!
 *    @brief Compute lux from ALS reading.
 *    @param rawALS raw ALS register value
 *    @param corrected if true, apply non-linear correction
 *    @return lux value
 */
float VEML3235::computeLux(uint16_t rawALS, bool corrected) {
  float lux = getResolution() * rawALS;
  if (corrected)
    lux = (((6.0135e-13 * lux - 9.3924e-9) * lux + 8.1488e-5) * lux + 1.0023) *
          lux;
  return lux;
}

void VEML3235::readWait(void) {
  // From app note:
  //   '''
  //   Without using the power-saving feature (PSM_EN = 0), the
  //   controller has to wait before reading out measurement results,
  //   at least for the programmed integration time. For example,
  //   for ALS_IT = 100 ms a wait time of ≥ 100 ms is needed.
  //   '''
  // Based on testing, it needs more. So doubling to be sure.

  unsigned long timeToWait = 2 * getIntegrationTimeValue(); // see above
  unsigned long timeWaited = millis() - lastRead;

  if (timeWaited < timeToWait)
    delay(timeToWait - timeWaited);
}

/*!
 *  @brief Implemenation of App Note "Designing the VEML7700 Into an
 * Application", Vishay Document Number: 84323, Fig. 24 Flow Chart. This will
 * automatically adjust gain and integration time as needed to obtain a good raw
 * count value. Additionally, a non-linear correction is applied if needed.
 */
float VEML3235::autoLux(void) {
  const uint8_t gains[] = {VEML3235_GAIN_1, VEML3235_GAIN_2, VEML3235_GAIN_4};
  const uint8_t intTimes[] = {VEML3235_IT_50MS,
                              VEML3235_IT_100MS, VEML3235_IT_200MS,
                              VEML3235_IT_400MS, VEML3235_IT_800MS};

  uint8_t gainIndex = 0;      // start with ALS gain = 1
  uint8_t itIndex = 0;        // start with ALS integration time = 50ms
  bool useCorrection = false; // flag for non-linear correction

  setGain(gains[gainIndex]);
  setIntegrationTime(intTimes[itIndex]);

  uint16_t ALS = readALS(true);
  // Serial.println("** AUTO LUX DEBUG **");
  // Serial.print("ALS initial = "); Serial.println(ALS);

  if (ALS <= 1000) {

    // increase first gain and then increase integration time as needed
    // compute lux using simple linear formula
    while ((ALS <= 1000) && !((gainIndex == 2) && (itIndex == 4))) {
      if (gainIndex < 2) {
        setGain(gains[++gainIndex]);
      } else if (itIndex < 4) {
        setIntegrationTime(intTimes[++itIndex]);
      }
      ALS = readALS(true);
      // Serial.print("ALS low lux = "); Serial.println(ALS);
    }

  } else {

    // decrease integration time as needed
    // compute lux using non-linear correction
    useCorrection = true;
    while ((ALS > 10000) && (itIndex > 0)) {
      setIntegrationTime(intTimes[--itIndex]);
      ALS = readALS(true);
      // Serial.print("ALS  hi lux = "); Serial.println(ALS);
    }
  }
  // Serial.println("** AUTO LUX DEBUG **");

  return computeLux(ALS, useCorrection);
}