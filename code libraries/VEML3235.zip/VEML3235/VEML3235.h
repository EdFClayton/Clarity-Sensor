/*!
 *  @file VEML3235.h
 *
 * 	I2C Driver for VEML3235 Lux sensor
 *
 * 	This is adapted from the library for the Adafruit VEML7700 breakout:
 * 	http://www.adafruit.com/
 *
 * 	Author: E Clayton 18/11/2023 University of Auckland
 *
 *	v0.1 - Draft release
 *	BSD license (see license.txt)
 */

#ifndef VEML3235_H
#define VEML3235_H

#include "Arduino.h"
#include <Adafruit_I2CDevice.h>
#include <Adafruit_I2CRegister.h>
#include <Wire.h>

#define VEML3235_I2CADDR_DEFAULT 0x10 	///< I2C address

#define VEML3235_ALS_CONFIG 0x00        	///< Light configuration register
#define VEML3235_ALS_DATA 0x05          	///< The light data output
#define VEML3235_WHITE_DATA 0x04        	///< The white light data output

#define VEML3235_GAIN_1 0x00   	///< ALS gain 1x
#define VEML3235_GAIN_2 0x01   	///< ALS gain 2x
#define VEML3235_GAIN_4 0x03 	///< ALS gain 4x

#define VEML3235_IT_50MS 0x00  	///< ALS integration time 50ms
#define VEML3235_IT_100MS 0x01 	///< ALS integration time 100ms
#define VEML3235_IT_200MS 0x02 	///< ALS integration time 200ms
#define VEML3235_IT_400MS 0x03 	///< ALS integration time 400ms
#define VEML3235_IT_800MS 0x04 	///< ALS integration time 800ms

#define VEML3235_SD 0x0F	///< Shutdown of ALS and White light
#define VEML3235_SD0 0x00	///< Shutdown BG and LDO


/*!
 *  @brief Used to explicitly annotate switch case fall throughs.
 *         Newer compilers will throw a warning otherwise.
 */
#if defined(__GNUC__) && __GNUC__ >= 7
#define VEML3235_FALLTHROUGH __attribute__((fallthrough));
#else
#define VEML3235_FALLTHROUGH
#endif

/** Options for lux reading method */
typedef enum {
  VEML_LUX_NORMAL,
  VEML_LUX_CORRECTED,
  VEML_LUX_AUTO,
  VEML_LUX_NORMAL_NOWAIT,
  VEML_LUX_CORRECTED_NOWAIT
} luxMethod;

/*!
 *    @brief  Class that stores state and functions for interacting with
 *            VEML3235 Light Sensor
 */
class VEML3235 {
public:
  VEML3235();
  bool begin(TwoWire *theWire = &Wire);

  void enable(bool enable);
  bool enabled(void);
  void turnOn(bool turnOn);
  bool ALS_SD = false;
  bool PowerSave = false;
  
  void setIntegrationTime(uint8_t it, bool wait = true);
  uint8_t getIntegrationTime(void);
  int getIntegrationTimeValue(void);
  
  void setGain(uint8_t gain);
  uint8_t getGain(void);
  float getGainValue(void);

  uint16_t readALS(bool wait = true);
  uint16_t readWhite(bool wait = false);
  float readLux(luxMethod method = VEML_LUX_NORMAL);

private:
  const float MAX_RES = 0.00426;
  const float GAIN_MAX = 4;
  const float IT_MAX = 800;
  float getResolution(void);
  float computeLux(uint16_t rawALS, bool corrected = false);
  float autoLux(void);
  void readWait(void);
  unsigned long lastRead;
  //int32_t _sensorID;

  Adafruit_I2CRegister *ALS_Config, *ALS_Data, *White_Data;
  Adafruit_I2CRegisterBits *ALS_Shutdown, *Power_Save, *ALS_Integration_Time, *ALS_Gain;
  Adafruit_I2CDevice *i2c_dev;
};

#endif
