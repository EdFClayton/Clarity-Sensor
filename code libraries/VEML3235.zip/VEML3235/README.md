This library is an adaptation of the Adafruit_VEML7700 library:

Adafruit_VEML7700 [![Build Status](https://github.com/adafruit/Adafruit_VEML7700/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_VEML7700/actions)

Communicates with the Vishay VEML3235 ambient light sensor via I2C.

Written by E Clayton 18 November 2023 University of Auckland
