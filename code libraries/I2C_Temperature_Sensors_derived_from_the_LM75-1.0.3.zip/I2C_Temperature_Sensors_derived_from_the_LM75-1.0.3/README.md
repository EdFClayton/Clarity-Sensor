# Arduino library for I²C Temperature Sensors derived from the LM75 #

This library supports a large range of I²C temperature sensors based on the industry-standard LM75 package, pinout, and/or protocol. See the [Sensors](doc/Sensors.md) page for a list of supported sensors.
